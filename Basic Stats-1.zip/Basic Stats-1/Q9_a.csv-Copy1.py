#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# In[5]:


df=pd.read_csv("Q9_a (1).csv")


# In[7]:


df


# In[8]:


# Skewness
df.skew()


# In[9]:


# Kurtosis
df.kurt()

